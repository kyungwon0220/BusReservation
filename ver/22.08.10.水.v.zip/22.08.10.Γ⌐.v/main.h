//#pragma once
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h> // system("cls");
#include <conio.h> // getch()
#include <string.h> // strcmp()
